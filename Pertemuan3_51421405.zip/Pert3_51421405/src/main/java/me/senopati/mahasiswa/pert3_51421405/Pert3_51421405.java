/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.senopati.mahasiswa.pert3_51421405;

/**
 *
 * @author totos
 */
public class Pert3_51421405 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
